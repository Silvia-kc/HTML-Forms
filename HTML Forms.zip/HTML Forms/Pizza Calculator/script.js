document.getElementById("calcBtn").addEventListener("click", function() {
  const name = document.getElementById("name").value.trim();
  const pizza = document.querySelector('input[name="pizza"]:checked');
  const size = parseFloat(document.getElementById("size").value);
  const count = parseInt(document.getElementById("count").value);

  const result = document.getElementById("result");

  if (!name || !pizza) {
    result.textContent = "Моля, попълнете всички полета и изберете пица!";
    result.style.color = "red";
    return;
  }

  const basePrice = parseFloat(pizza.value);
  const total = (basePrice + size) * count;

  result.style.color = "green";
  result.textContent = `Здравей, ${name}! Общата цена на поръчката е ${total} лв.`;
});